#!/bin/bash
streamlit run app.py